# Batch 01: 01_install_kernel

Mission: Install AmbitionsExperienceKernel into Packages and wire the app target import without changing product IA.

Constraints:
- Repo truth wins over package assumptions.
- Preserve Today / Goals / Capture / Time / You.
- Preserve primary object contracts from `surface_contracts.json`.
- Use local deterministic runtime state for living visuals.
- Preserve privacy: no content-bearing telemetry.

Implementation steps:
1. Inspect current repo state and list files touched.
2. Apply the smallest coherent migration for this batch.
3. Add or update tests, previews, scripts, and proof artifacts.
4. Run validation commands from `Docs/ValidationCommands.md`.
5. Produce Green Yellow Red status with blockers and rollback notes.

Acceptance:
- Build or manifest validation passes for files touched.
- AmbitionsExperienceKernel contracts remain valid.
- No weak generic UI patterns are introduced.
- Codex output includes exact changed files and validation logs.
